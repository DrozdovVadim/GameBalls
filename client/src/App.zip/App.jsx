import React, {useState, useEffect} from 'react';
import axios from 'axios';
import logo from './logo.svg';
import './App.css';

function App() {
  const [result, setResult]= useState({
    name:'',
    score: 0
  });
  const sendInf = async () =>
  {
    try{
      await axios.post('/result', {...result}, {
        headers:{
          'Content-Type': 'applications/json'
        }
        
      })
      .then(response =>console.log(response))
    } catch(err) {console.log(err)};
  }
  const giveInf = (event) =>
  {
    setResult({... result, [event.target.name]: event.target.value});
    console.log(result);
  };
  return(
    <div>
      <form onSubmit={e =>e.preventDefault()} >
      <input
      type="text" 
      name='name' 
      onChange={giveInf}
      />
      <input
      type="number"
      name='score'
      onChange={giveInf}
      />
      <button
      onClick={sendInf}
      >
        задать значения
      </button>
      </form>
    </div>
  )
}

export default App;
